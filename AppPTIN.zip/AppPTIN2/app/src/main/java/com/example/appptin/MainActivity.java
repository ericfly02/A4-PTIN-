package com.example.appptin;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SearchView searchView;
    private List<Medicamento> elementos = new ArrayList<>();
    private List<Medicamento> resultados = new ArrayList<>();

    private Button button, button2, button3, button4, button5, button6, button7, button8;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Agregar elementos a la lista
        elementos.add(new Medicamento("Paracetamol", 1.50, "Antibiótico", "Normon"));
        elementos.add(new Medicamento("Fluimucil", 2.00, "Analgésico", "Teva"));
        // ...

        searchView = findViewById(R.id.search_view);
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Limpiar la lista temporal
                resultados.clear();

                // Recorrer la lista de elementos
                for (Medicamento elemento : elementos) {
                    // Si el elemento contiene el texto de búsqueda, agregarlo a la lista temporal
                    if (elemento.getNombre().toLowerCase().contains(query.toLowerCase())) {
                        resultados.add(elemento);
                    }
                }
                // Actualizar la vista con la lista temporal utilizando un ListView
                ListView listView = findViewById(R.id.list_view);
                ArrayAdapter<Medicamento> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, resultados);
                listView.setAdapter(adapter);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                // Obtener el texto de búsqueda actual
                String query = searchView.getQuery().toString().trim();
                // Comprobar si el texto de búsqueda está vacío
                if (query.isEmpty()) {
                    // Si está vacío, mostrar todos los botones
                    button.setVisibility(View.VISIBLE);
                    button2.setVisibility(View.VISIBLE);
                    button3.setVisibility(View.VISIBLE);
                    button4.setVisibility(View.VISIBLE);
                    button5.setVisibility(View.VISIBLE);
                    button6.setVisibility(View.VISIBLE);
                    button7.setVisibility(View.VISIBLE);
                    button8.setVisibility(View.VISIBLE);
                } else {
                    // Si no está vacío, ocultar los botones
                    button.setVisibility(View.GONE);
                    button2.setVisibility(View.GONE);
                    button3.setVisibility(View.GONE);
                    button4.setVisibility(View.GONE);
                    button5.setVisibility(View.GONE);
                    button6.setVisibility(View.GONE);
                    button7.setVisibility(View.GONE);
                    button8.setVisibility(View.GONE);
                }

                // Actualizar los resultados de búsqueda según se va escribiendo
                // Limpiar la lista temporal
                resultados.clear();

                // Si el texto de búsqueda está vacío, no mostrar ningún resultado
                if (newText.isEmpty()) {
                    ListView listView = findViewById(R.id.list_view);
                    ArrayAdapter<Medicamento> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, resultados);
                    listView.setAdapter(adapter);
                    return true;
                }

                // Recorrer la lista de elementos
                for (Medicamento elemento : elementos) {
                    // Si el elemento contiene el texto de búsqueda y no hemos alcanzado el límite de 5, agregarlo a la lista temporal
                    if (elemento.getNombre().toLowerCase().contains(newText.toLowerCase())) {
                        resultados.add(elemento);
                    }
                }
                // Actualizar la vista con la lista temporal utilizando un ListView
                ListView listView = findViewById(R.id.list_view);
                ArrayAdapter<Medicamento> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, resultados);
                listView.setAdapter(adapter);
                return true;



            }


        });

        searchView = findViewById(R.id.search_view);
        Button btnFiltro = findViewById(R.id.btn_filtro);

        btnFiltro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FiltrosActivity.class);
                startActivity(intent);
            }
        });



    }
}
