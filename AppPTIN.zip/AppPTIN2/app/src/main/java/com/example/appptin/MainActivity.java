package com.example.appptin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SearchView searchView;
    private List<String> elementos = new ArrayList<>();
    private List<String> resultados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Agregar elementos a la lista
        elementos.add("Elemento 1");
        elementos.add("Elemento 2");
        elementos.add("Otro elemento");
        // ...
        searchView = findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Manejar la búsqueda aquí
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Actualizar los resultados de búsqueda según se va escribiendo
                // Limpiar la lista temporal
                resultados.clear();

                // Recorrer la lista de elementos
                for (String elemento : elementos) {
                    // Si el elemento contiene el texto de búsqueda, agregarlo a la lista temporal
                    if (elemento.toLowerCase().contains(newText.toLowerCase())) {
                        resultados.add(elemento);
                    }
                }
                // Actualizar la vista con la lista temporal utilizando un ListView
                ListView listView = findViewById(R.id.list_view);
                ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, resultados);
                listView.setAdapter(adapter);
                return true;
            }
        });


    }
}